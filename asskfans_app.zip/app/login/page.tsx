import LoginGate from '@/components/LoginGate'; export default function LoginPage(){ return <LoginGate />; }
